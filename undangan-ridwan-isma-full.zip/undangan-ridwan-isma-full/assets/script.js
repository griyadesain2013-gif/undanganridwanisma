
const TARGET = new Date('2025-12-03T10:00:00+07:00');
function startCountdown(){
  const d = document.getElementById('d'), h = document.getElementById('h'), m = document.getElementById('m'), s = document.getElementById('s');
  function update(){
    const now = new Date(); const diff = TARGET - now;
    if(diff<=0){ d.textContent=h.textContent=m.textContent=s.textContent='00'; return; }
    const days = Math.floor(diff/86400000);
    const hrs = Math.floor(diff%86400000/3600000);
    const mins = Math.floor(diff%3600000/60000);
    const secs = Math.floor(diff%60000/1000);
    d.textContent=String(days).padStart(2,'0'); h.textContent=String(hrs).padStart(2,'0');
    m.textContent=String(mins).padStart(2,'0'); s.textContent=String(secs).padStart(2,'0');
  }
  update(); setInterval(update,1000);
}
function init(){
  startCountdown();
  const bgm = document.getElementById('bgm');
  document.getElementById('play').addEventListener('click', ()=>bgm.play());
  document.getElementById('pause').addEventListener('click', ()=>bgm.pause());
  document.getElementById('openMap').addEventListener('click', ()=>window.open('https://maps.app.goo.gl/xiooKazu79GLVKJx9','_blank'));
  document.getElementById('rsvpBtn').addEventListener('click', ()=>window.open('https://wa.link/wg6chz','_blank'));
  document.querySelectorAll('[data-scroll]').forEach(el=>el.addEventListener('click', (e)=>{ const id = el.getAttribute('data-scroll'); document.getElementById(id).scrollIntoView({behavior:'smooth'}); }));
  const toParam = new URLSearchParams(location.search).get('to') || '';
  if(toParam){ const name = decodeURIComponent(toParam.replace(/\+/g,' ')); document.querySelectorAll('.to-line').forEach(x=>x.textContent = `Kepada Yth. ${name}`); }
}
window.addEventListener('DOMContentLoaded', init);
