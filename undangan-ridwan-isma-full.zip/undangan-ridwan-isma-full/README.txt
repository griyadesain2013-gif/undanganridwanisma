Paket Undangan Ridwan & Isma — Editable Full
=============================================
Isi paket:
- index.html
- assets/style.css
- assets/script.js
- assets/images/canva_1.png ... canva_7.png (diambil dari Canva yang kamu kirim)
- Musik: placeholder mixkit (ganti jika ingin pakai file MP3 dari Canva)

Cara cepat deploy (Netlify Drop):
1. Zip folder 'undangan-ridwan-isma-full' jadi undangan-ridwan-isma-full.zip
2. Buka https://app.netlify.com/drop dan drag & drop file zip.
3. Tunggu deploy dan dapatkan link publik.

Note:
- Tombol Konfirmasi membuka WhatsApp: https://wa.link/wg6chz
- Tombol Buka Map membuka: https://maps.app.goo.gl/xiooKazu79GLVKJx9
- Untuk menampilkan nama tamu otomatis, tambahkan ?to=Nama%20Tamu pada URL.
